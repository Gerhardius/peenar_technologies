const totalPairs = 10;
let images = [];
let cards = [];
let revealedCards = [];
let matchedPairs = 0;
    
let playerCount = 2;
let currentPlayer = 0;
let scores = [];

let clientId = null;
let clientCount = 0;
let isMasterClient = false;

const webRoomsWebSocketServerAddr = 'wss://nosch.uber.space/web-rooms/';
const socket = new WebSocket(webRoomsWebSocketServerAddr);

socket.addEventListener('open', () => {
  sendRequest('*enter-room*', 'touch-touch');
  sendRequest('*subscribe-client-count*');
  setInterval(() => socket.send(''), 30000);
});

socket.addEventListener('close', () => {
  clientId = null;
  document.body.classList.add('disconnected');
});

socket.addEventListener('message', (event) => {
  const data = event.data;
  if (!data) return;

  const incoming = JSON.parse(data);
  const selector = incoming[0];

  switch (selector) {
    case '*client-id*':
      clientId = incoming[1];
      isMasterClient = clientId === 1;
      if (isMasterClient) {
        document.getElementById("controls").style.display = "block";
      }
      break;

    case '*client-count*':
      clientCount = incoming[1];
      break;

    case 'init-game':
      cards = incoming[1];
      playerCount = incoming[2];
      scores = Array(playerCount).fill(0);
      currentPlayer = 0;
      matchedPairs = 0;
      updateUI();
      renderBoard();
      break;

    case 'reveal':
      if (incoming[2] === currentPlayer) {
        doRevealCard(incoming[1]);
      }
      break;

    case 'next-turn':
      currentPlayer = incoming[1];
      updateUI();
      break;

    case 'update-scores':
      scores = incoming[1];
      updateUI();
      break;

    default:
      break;
  }
});

function sendRequest(...message) {
  socket.send(JSON.stringify(message));
}

function startGame() {
  if (!isMasterClient) return;
  playerCount = parseInt(document.getElementById("playerCount").value);
  if (isNaN(playerCount) || playerCount < 1 || playerCount > 5) {
    alert("Bitte Spieleranzahl zwischen 1 und 5 wählen.");
    return;
  }
  loadImages();
  shuffleCards();
  scores = Array(playerCount).fill(0);
  sendRequest('init-game', cards, playerCount);
}

function restartGame() {
  if (isMasterClient) {
    startGame();
  }
}

function loadImages() {
  images = [];
  for (let i = 1; i <= totalPairs; i++) {
    images.push(`img/bild${i}.jpg`);
  }
  cards = [...images, ...images];
}

function shuffleCards() {
  for (let i = cards.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [cards[i], cards[j]] = [cards[j], cards[i]];
  }
}

function renderBoard() {
  const board = document.getElementById("board");
  board.innerHTML = "";

  cards.forEach((src, index) => {
    const card = document.createElement("div");
    card.className = "card";
    card.dataset.index = index;

    const img = document.createElement("img");
    img.src = src;
    img.style.visibility = "hidden";

    card.appendChild(img);
    card.addEventListener("click", () => {
      if (revealedCards.length < 2 && clientId === currentPlayer + 1) {
        sendRequest('reveal', index, currentPlayer);
      }
    });

    board.appendChild(card);
  });
}

function doRevealCard(index) {
  const cardElem = document.querySelector(`[data-index='${index}']`);
  if (!cardElem || cardElem.classList.contains("revealed") || cardElem.classList.contains("matched")) return;

  const img = cardElem.querySelector("img");
  img.style.visibility = "visible";
  cardElem.classList.add("revealed");
  revealedCards.push({ card: cardElem, index });

  if (revealedCards.length === 2) {
    checkMatch();
  }
}

function checkMatch() {
  const [first, second] = revealedCards;
  const firstImg = cards[first.index];
  const secondImg = cards[second.index];

  if (firstImg === secondImg) {
    first.card.classList.add("matched");
    second.card.classList.add("matched");
    scores[currentPlayer]++;
    matchedPairs++;
    sendRequest('update-scores', scores);
    revealedCards = [];

    if (matchedPairs === totalPairs) {
      setTimeout(showWinner, 500);
    }
  } else {
    setTimeout(() => {
      first.card.classList.remove("revealed");
      second.card.classList.remove("revealed");
      first.card.querySelector("img").style.visibility = "hidden";
      second.card.querySelector("img").style.visibility = "hidden";
      revealedCards = [];
    }, 1000);
    currentPlayer = (currentPlayer + 1) % playerCount;
    sendRequest('next-turn', currentPlayer);
  }
}

function updateUI() {
  document.getElementById("currentPlayer").textContent = `Spieler ${currentPlayer + 1} ist am Zug`;
  document.getElementById("scores").textContent = scores.map((s, i) => `Spieler ${i + 1}: ${s}`).join(' | ');
}

function showWinner() {
  const maxScore = Math.max(...scores);
  const winnerIndices = scores
    .map((s, i) => (s === maxScore ? i + 1 : null))
    .filter((v) => v !== null);
  alert(`Spiel beendet! Gewinner: Spieler ${winnerIndices.join(", ")}`);
}

